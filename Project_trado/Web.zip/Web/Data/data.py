class Data:

    url_trado = "https://qa.trado.co.il/"
    url_admin = "https://qa-admin.trado.co.il/#/login"




