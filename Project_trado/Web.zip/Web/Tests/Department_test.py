import allure
import pytest

from Web.Pages.Department_page  import *

class Test_Promotion(PromotionPage, BasePage):

    def handling_the_first_popup(self):
        self.open()
        self.select_option1()
        self.select_option2()
        self.click_save()