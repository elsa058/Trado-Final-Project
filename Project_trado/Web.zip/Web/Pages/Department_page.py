from Web.BasePage.basepage import BasePage
from Web.Data.data import *
from Web.Locators.Department_loactors  import Promo_Locator


class PromotionPage(BasePage, Promo_Locator, Data):

    def select_option1(self):
        self._click(self.option1)

    def click_save(self):
        self._click(self.save)

    def select_option2(self):
        self._click(self.option2)