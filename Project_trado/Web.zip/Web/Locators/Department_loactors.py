from selenium.webdriver.common.by import By


class Promo_Locator:
    url=()
